package edu.model;

//import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;
//import org.springframework.context.annotation.Scope;

import javax.persistence.*;
import java.io.Serializable;



@Entity
public class VoterDetail implements Serializable{

    private static final long serialVersionUID = 15L;

	@NotEmpty (message = "Voter name can not be empty.")
    private String voterFullname;

	@NotEmpty (message = "Date of Birth can not be empty.")
    private String voterDOB;
	
	@Id
	@NotEmpty(message = "Security code can not be empty")
	private String voterSecuritycode;
	
	@Id
	@NotEmpty (message = "Email name can not be empty.")
    private String voterEmailid;

    @NotEmpty (message = "Password must not be empty.")
    private String voterPassword;

    private boolean enabled;
  
    @NotEmpty (message = "Address must not be empty.")
	private String voterAddress;

	public String getVoterFullname() {
		return voterFullname;
	}

	public void setVoterFullname(String voterFullname) {
		this.voterFullname = voterFullname;
	}

	public String getVoterDOB() {
		return voterDOB;
	}

	public void setVoterDOB(String voterDOB) {
		this.voterDOB = voterDOB;
	}

	public String getVoterSecuritycode() {
		return voterSecuritycode;
	}

	public void setVoterSecuritycode(String voterSecuritycode) {
		this.voterSecuritycode = voterSecuritycode;
	}

	public String getVoterEmailid() {
		return voterEmailid;
	}

	public void setVoterEmailid(String voterEmailid) {
		this.voterEmailid = voterEmailid;
	}

	public String getVoterPassword() {
		return voterPassword;
	}

	public void setVoterPassword(String voterPassword) {
		this.voterPassword = voterPassword;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getVoterAddress() {
		return voterAddress;
	}

	public void setVoterAddress(String voterAddress) {
		this.voterAddress = voterAddress;
	}

    

    
}
