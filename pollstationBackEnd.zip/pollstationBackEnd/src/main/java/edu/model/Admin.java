package edu.model;

import javax.persistence.*;


import org.springframework.stereotype.Component;

@Entity
@Table(name = "Electoral Officer")
@Component
public class Admin {
	@Id
	@Column(name="adminname")
	private String adminname;
	private String password;
	private long contactnumber;
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}
	
}
