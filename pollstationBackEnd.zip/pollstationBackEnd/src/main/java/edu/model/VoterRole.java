package edu.model;


import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class VoterRole implements Serializable {
	
	private static final long serialVersionUID = 19L;

	@Id
    private String securitycode;
    private String emailid;
    private String role;
	public String getSecuritycode() {
		return securitycode;
	}
	public void setSecuritycode(String securitycode) {
		this.securitycode = securitycode;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
    


   
}

