package edu.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import edu.model.VoterRole;

import edu.model.VoterDetail;
import edu.model.Voters;


@Repository("voterDAO")
@Transactional
public class VoterDAOImpl implements VoterDAO {
	 @Autowired
	    private SessionFactory sessionFactory;

	    public VoterDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory=sessionFactory;
	}

		public void addVoter(VoterDetail voterDetail) {
	        Session session = sessionFactory.getCurrentSession();

	        // voterDetail.getVoterAddress().setVotersDetail(voterDetail);
	        

	        session.saveOrUpdate(voterDetail);
	        
	        session.saveOrUpdate(voterDetail.getVoterAddress());
	        

	        Voters newVoter = new Voters();
	        newVoter.setFullname(voterDetail.getVoterFullname());
	        newVoter.setDob(voterDetail.getVoterDOB());
	        newVoter.setAddress(voterDetail.getVoterAddress());
	        newVoter.setSecuritycode(voterDetail.getVoterSecuritycode());
	        newVoter.setEmailid(voterDetail.getVoterEmailid());
	        newVoter.setPassword(voterDetail.getVoterPassword());
	        newVoter.setEnabled(true);
	       

	        VoterRole newVoterRole = new VoterRole();
	        newVoterRole.setSecuritycode(voterDetail.getVoterSecuritycode());
	        newVoterRole.setRole("ROLE_VOTER");
	        session.saveOrUpdate(newVoter);
	        session.saveOrUpdate(newVoterRole);


	       
	        

	        session.flush();
	    }

	    public VoterDetail getVoterBySecurityCode (String securitycode) {
	        Session session = sessionFactory.getCurrentSession();
	        return (VoterDetail) session.get(VoterDetail.class, voterSecuritycode);
	    }

	    public List<VoterDetail> getAllVoterss() {
	        Session session = sessionFactory.getCurrentSession();
	        Query query = session.createQuery("from VoterDetail");
	        @SuppressWarnings("unchecked")
			List<VoterDetail> voterDetail = query.list();

	        return voterDetail;
	    }

	    public VoterDetail getVoterByEmailid (String emailid) {
	        Session session = sessionFactory.getCurrentSession();
	        Query query = session.createQuery("from VoterDetail where username = ?");
	        query.setString(0, emailid);

	        return (VoterDetail) query.uniqueResult();
	    }

	
}
