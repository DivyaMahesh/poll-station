package edu.dao;

import java.util.List;

import edu.model.Admin;

public interface AdminDAO {
	
	public List<Admin> adminlist();
	
	public void adminSaveorUpdate(Admin admin);
	
	public void adminDelete(String adminname);
	
	public Admin get(String adminname);
	
	public boolean isValidAdmin(String adminname, String password);

}
