package edu.dao;

import java.util.List;

import edu.model.VoterDetail;
import edu.model.Voters;

public interface VoterDAO {
	
	public List<Voters> voterslist();
	
	public void addVoter(VoterDetail voterDetail);
	
	public VoterDetail getVoterBySecurityCode(String securitycode);
	
	public List<VoterDetail> getAllVoters();
	
	public VoterDetail getVoterByEmailid (String emailid);
	
	
	
	
	

}
