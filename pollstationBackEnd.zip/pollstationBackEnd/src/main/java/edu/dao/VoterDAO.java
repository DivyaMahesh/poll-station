package edu.dao;

public interface VoterDAO {

}
