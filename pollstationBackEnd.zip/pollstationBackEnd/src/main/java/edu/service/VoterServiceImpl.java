package edu.service;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.dao.VoterDAO;
import edu.model.VoterDetail;

import java.util.List;

@Service
public abstract class VoterServiceImpl implements VoterService {
	@Autowired
	private VoterDAO voterDAO;
	@Autowired
	SessionFactory sessionFactory;

	public VoterServiceImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void addVoter(VoterDetail voterDetail) {
		voterDAO.addVoter(voterDetail);
	}

	public VoterDetail getVoterBySecurityCode(String securitycode) {
		return voterDAO.getVoterBySecurityCode(securitycode);
	}

	public List<VoterDetail> getAllVoters() {
		return voterDAO.getAllVoters();
	}

	public VoterDetail getUserByEmailid(String emailid) {
		return voterDAO.getVoterByEmailid(emailid);
	}

}
