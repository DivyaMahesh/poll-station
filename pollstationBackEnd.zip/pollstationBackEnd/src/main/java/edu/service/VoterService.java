package edu.service;

import java.util.List;

import edu.model.VoterDetail;

public interface VoterService {

	public void addVoter(VoterDetail votersDetail);
	public VoterDetail getVoterBySecurityCode(String securitycode);
	public List<VoterDetail> getAllVoters();
	public VoterDetail getUserByUsername(String username);
}
