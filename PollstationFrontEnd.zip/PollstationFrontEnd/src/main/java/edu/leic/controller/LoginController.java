
package edu.leic.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.model.VoterDetail;
import edu.service.VoterService;


@Controller
public class LoginController {

	 @Autowired
	    private VoterService userService;
	   
	 @RequestMapping("signin")
	    public String login(@RequestParam(value="error", required = false) String error, @RequestParam(value="logout",
	            required = false) String logout, Model model) {
	        if (error!=null) {
	            model.addAttribute("error", "Invalid emailid and password");
	        }

	        if(logout!=null) {
	            model.addAttribute("msg", "You have been logged out successfully.");
	        }

	        return "signin";
	    }

		@RequestMapping("adminhome")
	public ModelAndView onLoadAdminHome()
	{
		ModelAndView mv=new ModelAndView("adminhome");
	
		return mv;
	}
	/*@RequestMapping("signin")
	public ModelAndView onLoadSignin()
	{
		ModelAndView mv=new ModelAndView("signin");
	
		return mv;
	}*/
		 @RequestMapping(value = "register", method = RequestMethod.POST)
	    public String registerUserPost(@Valid @ModelAttribute("voterDetail") VoterDetail voterDetail, BindingResult result,
	                                       Model model) {
			 String message;

	        if (result.hasErrors()) {
	        	
	            return "signin";
	        }

	        List<VoterDetail> voterDetailList=userService.getAllVoters();

	        for (int i=0; i< voterDetailList.size(); i++) {
	            if(voterDetail.getVoterEmailid().equals(voterDetailList.get(i).getVoterEmailid())) {
	                model.addAttribute("emailMsg", "Email already exists");

	                return "home";
	            }

	            if(voterDetail.getVoterSecuritycode().equals(voterDetailList.get(i).getVoterSecuritycode())) {
	                model.addAttribute("SecuritycodeMsg", "SecurityCode already exists");

	                return "home";
	            }
	        }

	        voterDetail.setEnabled(true);
	        userService.addVoter(voterDetail);
	        message="Registered succesfully";
	        model.addAttribute("message",message);
	        return "signin";

	    }
		 

}
